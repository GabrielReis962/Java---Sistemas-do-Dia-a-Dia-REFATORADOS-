package Sistema_de_Controle_de_Estacionamento_refactor;// Data: 22/05/2026





class Veiculo {

    private String placa;
    private String tipo;
    private int horarioEntrada;

    public Veiculo(String placa, String tipo, int horarioEntrada) {
        this.placa = placa;
        this.tipo = tipo;
        this.horarioEntrada = horarioEntrada;
    }


    public String getPlaca() {
        return placa;
    }

    public String getTipo() {
        return tipo;
    }

    public int getHorarioEntrada() {
        return horarioEntrada;
    }
}