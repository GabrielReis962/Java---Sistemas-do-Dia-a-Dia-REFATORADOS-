package Sistema_de_Controle_de_Estacionamento_refactor; // Data: 22/05/2026
import java.util.Scanner;


import java.util.Random;

class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Random random = new Random();


        System.out.print("Placa do veículo: ");
        String placa = sc.nextLine();

        System.out.print("Tipo do veículo (carro/moto): ");
        String tipo = sc.nextLine();


        boolean vagas;
        if (tipo.equalsIgnoreCase("moto")) {
            vagas = random.nextInt(100) < 80;
        } else {
            vagas = random.nextInt(100) < 50;
        }


        if (!vagas) {
            System.out.println("Estacionamento lotado.");
            return;
        }

        System.out.println("Há vagas.");


        int horarioEntrada = -1;
        while (horarioEntrada < 0 || horarioEntrada > 23) {
            System.out.print("Horário de entrada (0h a 23h): ");
            horarioEntrada = sc.nextInt();
            if (horarioEntrada < 0 || horarioEntrada > 23) {
                System.out.println("Horário inválido! Digite um valor entre 0 e 23.");
            }
        }


        Veiculo v1 = new Veiculo(placa, tipo, horarioEntrada);


        int horarioSaida = -1;
        while (horarioSaida < 0 || horarioSaida > 23) {
            System.out.print("Horário de saída (0h a 23h): ");

            horarioSaida = sc.nextInt();
            if (horarioSaida < 0 || horarioSaida > 23) {
                System.out.println("Horário inválido! Digite um valor entre 0 e 23.");
            }
        }


        int horas;
        if (horarioSaida >= v1.getHorarioEntrada()) {
            horas = horarioSaida - v1.getHorarioEntrada();
        } else {
            horas = (24 - v1.getHorarioEntrada()) + horarioSaida;
        }


        if (horas == 0) {
            horas = 1;
        }


        double valor;
        if (horas <= 1) {
            valor = 10.0;
        } else {
            valor = 10.0 + ((horas - 1) * 5.0);
        }


        System.out.println("\n--- DADOS ---");
        System.out.println("Placa: " + v1.getPlaca());
        System.out.println("Tipo: " + v1.getTipo());
        System.out.println("Horário de entrada: " + v1.getHorarioEntrada() + "h");
        System.out.println("Horário de saída: " + horarioSaida + "h");
        System.out.println("Tempo estacionado: " + horas + " hora(s)");
        System.out.println("Valor total: R$ " + valor);

        sc.nextLine();


        System.out.print("Forma de pagamento: ");
        String pagamento = sc.nextLine();

        System.out.print("Pagamento aprovado? (true/false): ");
        boolean aprovado = sc.nextBoolean();

        if (!aprovado) {
            System.out.println("Pagamento não autorizado.");
        } else {
            System.out.println("Saída liberada.");
        }

        sc.close();
    }
}
